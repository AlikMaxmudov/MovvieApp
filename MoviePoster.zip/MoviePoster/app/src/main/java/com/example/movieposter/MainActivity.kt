package com.example.movieposter

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.movieposter.databinding.ActivityLoginBinding

class MainActivity : AppCompatActivity() {

    lateinit var bindingClass: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
